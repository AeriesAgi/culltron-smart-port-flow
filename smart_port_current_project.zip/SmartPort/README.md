# SmartPort — Intelligent Port Management Platform

> Enterprise port operations management system for South Africa's maritime industry.  
> **ASP.NET Core 8 MVC · PostgreSQL · Entity Framework Core · Docker**

---

## Overview

SmartPort is a production-oriented platform giving port operators, terminal managers, shipping agents, logistics partners, and executive stakeholders a unified operational intelligence layer:

- **Vessel & Berth Management** — scheduling, assignments, turnaround tracking
- **Container & Yard Operations** — tracking, dwell alerts, block utilisation
- **Gate & Truck Flow** — queue management, transaction logs, bottleneck detection
- **Document & Compliance Workflow** — full document lifecycle with approval/rejection
- **Incident & Alert Management** — severity triage, acknowledgment, resolution
- **AI Recommendations Engine** — rules-based operational suggestions with impact estimates
- **Analytics & Reporting** — throughput, turnaround, berth efficiency, yard density trends
- **Public Marketing Website** — professional product/company landing pages
- **Role-Based Access Control** — 5 operational roles with policy-based authorization

---

## Stack

| Layer | Technology |
|---|---|
| Backend | ASP.NET Core 8 MVC (C#) |
| Database | PostgreSQL 16 |
| ORM | Entity Framework Core 8 |
| Auth | ASP.NET Core Identity |
| Frontend | Razor Views + Chart.js + Feather Icons |
| Container | Docker / Docker Compose |
| Architecture | Clean Architecture (Domain / Application / Infrastructure / Web) |

---

## Solution Structure

```
SmartPort/
├── SmartPort.sln
├── Dockerfile
├── docker-compose.yml
├── .dockerignore
├── README.md
├── docs/
│   ├── ARCHITECTURE.md
│   ├── DEMO_SCRIPT.md
│   └── ROADMAP.md
├── scripts/
│   └── init.sql
└── src/
    ├── SmartPort.Domain/          # Entities, enums — no external deps
    ├── SmartPort.Application/     # Service interfaces, DTOs
    ├── SmartPort.Infrastructure/  # EF Core, services, seed data
    ├── SmartPort.Shared/          # Constants, roles, policies
    └── SmartPort.Web/             # ASP.NET Core MVC entry point
        ├── Controllers/
        ├── Views/
        │   ├── Dashboard/
        │   ├── Vessels/
        │   ├── Berths/
        │   ├── Containers/
        │   ├── Gates/
        │   ├── Incidents/
        │   ├── Documents/
        │   ├── Analytics/
        │   ├── Admin/
        │   ├── Auth/
        │   ├── Home/
        │   └── Shared/
        └── wwwroot/
            ├── css/   (app.css, public.css)
            └── js/    (app.js, public.js)
```

---

## Getting Started

### Option A — Docker Compose (recommended)

```bash
git clone <repo> SmartPort   # or unzip SmartPort.zip
cd SmartPort

docker compose up --build
```

On first run the application will:
1. Start PostgreSQL 16 and wait for it to be ready
2. Create the full database schema via `EnsureCreatedAsync()` — no migration files needed
3. Seed all demo data (users, vessels, containers, incidents, alerts, etc.)
4. Be accessible at **http://localhost:8080**

On subsequent `docker compose up` runs the schema step and seed step are both
no-ops, so the existing data is preserved.

---

### ♻️ Resetting the Database (clean slate)

To wipe all data and re-seed from scratch, stop the containers **and** delete
the named Docker volume that holds the PostgreSQL data:

```bash
# Stop containers and delete the database volume
docker compose down -v

# Rebuild images and start fresh — schema + seed runs again automatically
docker compose up --build
```

> **Why `-v`?**  Without `-v`, `docker compose down` stops containers but
> keeps the `smartport_pgdata` volume. The next `up` will connect to the
> existing populated database. Adding `-v` removes the volume so PostgreSQL
> starts completely empty on the next run.

---

### Option B — Local Development

**1. Start PostgreSQL**

```bash
docker run -d \
  --name smartport_db \
  -e POSTGRES_DB=smartport_dev \
  -e POSTGRES_USER=smartport \
  -e POSTGRES_PASSWORD=SmartPort2025! \
  -p 5432:5432 \
  postgres:16-alpine
```

**2. Confirm the connection string in** `src/SmartPort.Web/appsettings.Development.json`

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Host=localhost;Port=5432;Database=smartport_dev;Username=smartport;Password=SmartPort2025!"
  }
}
```

**3. Run the application**

```bash
cd src/SmartPort.Web
dotnet run
```

Browse to `https://localhost:5001` or `http://localhost:5000`

**Resetting locally:**

```bash
# Drop and recreate the dev database
docker exec smartport_db psql -U smartport -c "DROP DATABASE IF EXISTS smartport_dev;"
docker exec smartport_db psql -U smartport -c "CREATE DATABASE smartport_dev;"
# Then restart: dotnet run will recreate the schema and re-seed
```

---

## Demo Credentials

| Role | Email | Password |
|---|---|---|
| **Admin** | admin@smartport.co.za | SmartPort@2025! |
| **Port Operations Manager** | ops.manager@smartport.co.za | SmartPort@2025! |
| **Terminal Staff** | terminal1@smartport.co.za | SmartPort@2025! |
| **Logistics Partner** | logistics@freightco.co.za | SmartPort@2025! |
| **Executive Viewer** | executive@transnet.co.za | SmartPort@2025! |

---

## Key Routes

| URL | Description |
|---|---|
| `/` | Public landing page |
| `/product` | Platform overview |
| `/features` | Feature detail |
| `/pricing` | Commercial packages |
| `/demo` | Demo access page |
| `/contact` | Contact / enquiry |
| `/auth/login` | Login |
| `/dashboard` | Operations dashboard |
| `/vessels` | Vessel schedule |
| `/berths` | Berth management |
| `/containers` | Container tracking |
| `/containers/yard` | Yard overview |
| `/containers/track` | Container lookup |
| `/gates` | Gate operations |
| `/gates/trucks` | Truck queue |
| `/incidents` | Incident management |
| `/incidents/alerts` | Alert centre |
| `/incidents/recommendations` | AI insights |
| `/documents` | Document workflow |
| `/analytics` | Analytics & reporting |
| `/admin` | User management (Admin only) |

---

## Schema Strategy — Demo vs Production

### Demo / Prototype (current build)

`Program.cs` uses `EnsureCreatedAsync()` at startup. This creates the
complete PostgreSQL schema directly from the EF Core model with **no migration
files required**. It is safe to run repeatedly — it is a no-op if the schema
already exists.

This is the correct approach for demo, competition, and pilot builds where
you need `docker compose up --build` to work on any clean machine without
any pre-generation steps.

### Production upgrade path

When you are ready to add versioned schema migrations (required for
production where you cannot drop and recreate the database on upgrade):

```bash
# 1. Install the EF Core CLI tools (once per machine)
dotnet tool install --global dotnet-ef

# 2. Generate the initial migration from the current model
cd SmartPort   # solution root
dotnet ef migrations add InitialCreate \
  --startup-project src/SmartPort.Web \
  --project src/SmartPort.Infrastructure

# 3. In Program.cs, swap the two lines:
#    Replace:  await db.Database.EnsureCreatedAsync();
#    With:     await db.Database.MigrateAsync();

# 4. In Program.cs AddDbContext, add back:
#    b => b.MigrationsAssembly("SmartPort.Infrastructure")

# 5. For subsequent model changes, generate a new migration:
dotnet ef migrations add <DescriptiveName> \
  --startup-project src/SmartPort.Web \
  --project src/SmartPort.Infrastructure
```

> **Note:** `EnsureCreatedAsync()` and `MigrateAsync()` are **mutually
> exclusive**. Once you switch to migrations, do not use `EnsureCreatedAsync()`
> again — it will not apply pending migrations.

---

## Seeded Data

| Entity | Count |
|---|---|
| Users | 5 (one per role) |
| Berths | 8 (DCT, MPT, Oil Terminal) |
| Yard Blocks | 8 zones |
| Gates | 4 |
| Vessels | 6 (in port, arriving, departed) |
| Containers | 120 |
| Incidents | 5 |
| Alerts | 7 active |
| Documents | 6 |
| AI Recommendations | 4 |
| Operational Metrics | ~700 rows (90 days) |

---

## Phase 2 Integrations (Planned)

- AIS vessel position feed (MarineTraffic / exactEarth)
- SARS Customs EDI
- SAWS weather advisory
- SAMSA port authority notifications
- Email/SMS notifications
- PDF report generation

---

## Commercial Context

SmartPort targets: Transnet Port Terminals, private terminal operators, freight forwarders, and logistics companies operating in South Africa's port ecosystem.

**support@smartport.co.za** · Durban, KwaZulu-Natal, South Africa
